DataManager.java – Readme

Reasoning
Project requires text-file persistence only (no databases). So created this single class for save/load actions.

//////////////////////////////////////////////////////////////

Purpose
DataManager is the central persistence layer for system.

It provides one public API:

- saveAllData(Airline airline)
- loadAllData(Airline airline)

All managers (AirportManager, FlightManager, BookingManager, etc.) remain unchanged. DataManager only reads from and writes to simple text files in the data/folder.

//////////////////////////////////////////////////////////////

How It Achieves CRUD Persistence

CREATE / UPDATE
- Any GUI action that changes data (book seat, pay, add/update/remove in management screens) calls Main.saveData() immediately after the change.
- This triggers DataManager.saveAllData() which walks every manager’s getAllXXX() list and writes it to the matching .txt file.

READ
- On program start, Main.java calls DataManager.loadAllData() before dummy data or GUI launch.
- Each manager’s addXXX() or findXXX() methods are used to rebuild the in-memory collections from the text files.

DELETE
- Same flow as CREATE/UPDATE: after a remove operation in any manager, Main.saveData() writes the updated list to file.

Auto-Safety Features
- Creates data/ folder automatically
- Graceful first-run (no crash if files don’t exist)
- Shutdown hook in Main.java auto-saves on normal exit
- Console messages confirm every save/load

//////////////////////////////////////////////////////////////

Troubleshooting
Had to troubleshoot UnsupportedOperationException stubs that were breaking the GUI. DataManager was updated to eliminate these.

//////////////////////////////////////////////////////////////

Hand-Off Notes

Required Updates to Main.java

Current Main.java creates the Airline, runs dummyData() unconditionally, and launches the GUI — but contains no persistence calls. To make DataManager deliver full save/load across restarts, I had the following two blocs in Main.java as shown.

After implementing program will:
- Load first: restore all previous bookings, seats, tickets, etc. on startup (meets “defensive loading” critique)
- Use conditional dummyData: prevents duplicate flights on program runs
- Provide shutdown hook: guarantee data is saved with window closing
- saveData() helper: lets GUI buttons trigger a save without touching other code

These are the only changes needed in Main.java.

//////////////////////////////////////////////////////////////

// As main method:

    public static void main(String[] args) {

        airline = new Airline("SkyHigh Airlines");

        // === REQUIRED PERSISTENCE SETUP ===
        DataManager.loadAllData(airline);

        // Seed dummy data ONLY on first run (prevents duplication on every startup)
        if (airline.getFlightManager().getAllFlights().isEmpty()) {
            dummyData();
        }

        // Launch GUI on Event Dispatch Thread (unchanged)
        javax.swing.SwingUtilities.invokeLater(() -> {
            new MainMenuGUI(airline).setVisible(true);
        });

        // Auto-save on normal program exit (critical for GUI workflow)
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            DataManager.saveAllData(airline);
            System.out.println("All data automatically saved on exit.");
        }));
    }

//////////////////////////////////////////////////////////////

// After main method:

    */ 
    * GUI Helper
    * Needs to be called by SeatSelectionGUI, PaymentGUI, BookingManagementGUI, etc.
    /*
    public static void saveData() {
        if (airline != null) {
            DataManager.saveAllData(airline);
            System.out.println("💾 Data saved successfully after CRUD operation.");
        }
    }

//////////////////////////////////////////////////////////////

Save/Load Testing Workflow

1. Run the program: it will create the data/ folder and these files
2. Make a change in the GUI
3. Close the program
4. Re-open: loadAllData() will read these files and restore content
5. Check the console for confirmation messages

My recommended stub fixes for Flight.java & AirportManager.java & Booking.java need to be applied, and then these files will populate automatically, no manual editing.

If you ever change a save format, just update the matching saveXXX() / loadXXX() pair in DataManager.java.

Design is meant to SRP clean, make persistence explicit, and satisfies all Stage 3 critiques for working CRUD actions for seats, bookings, tickets, and management screens across program restarts.
