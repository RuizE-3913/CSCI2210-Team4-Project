package AirlineSystem;

import java.io.*;
import java.util.*;

/**
 * CENTRAL PERSISTENCE LAYER
 * 
 *
 * @author Eugene Ruiz
 * @author Joseph Heifner
 * @author Labeeb Md
 * @date 05-08-2026
 * 
 * Hand-off Notes:
 * - This class ONLY handles reading/writing to text files.
 * - It expects every manager to provide:
 *     • getAllXXX()   (returns iteration or List – defensive copy)
 *     • addXXX(item)  (for loading)
 * - Save is called after every major GUI action via Main.saveData()
 * - Load happens once at startup in Main.java before dummyData()
 * 
 * Simplistic class philosophy.
 */

public class DataManager {

    private static final String DATA_DIR = "data/";
    private static final String AIRPORTS_FILE   = DATA_DIR + "airports.txt";
    private static final String FLIGHTS_FILE    = DATA_DIR + "flights.txt";
    private static final String STAFF_FILE      = DATA_DIR + "staff.txt";
    private static final String PASSENGERS_FILE = DATA_DIR + "passengers.txt";
    private static final String BOOKINGS_FILE   = DATA_DIR + "bookings.txt";
    private static final String TICKETS_FILE    = DATA_DIR + "tickets.txt";

    private static void ensureDataDir() {
        new File(DATA_DIR).mkdirs();
    }

    // ====================== PUBLIC API ======================
    public static void saveAllData(Airline airline) {
        ensureDataDir();
        saveAirports(airline.getAirportManager());
        saveFlights(airline.getFlightManager());
        saveStaff(airline.getStaffManager());
        savePassengers(airline.getPassengerManager());
        saveBookings(airline.getBookingManager());
        saveTickets(airline.getTicketManager());
        System.out.println(" All data saved successfully.");
    }

    public static void loadAllData(Airline airline) {
        ensureDataDir();
        loadAirports(airline.getAirportManager());
        loadFlights(airline.getFlightManager(), airline.getAirportManager());
        loadStaff(airline.getStaffManager());
        loadPassengers(airline.getPassengerManager());
        loadBookings(airline.getBookingManager(), airline.getPassengerManager(), airline.getFlightManager());
        loadTickets(airline.getTicketManager(), airline.getFlightManager(), 
                   airline.getPassengerManager(), airline.getBookingManager());
        System.out.println(" All data loaded successfully.");
    }

    /**
     * Joseph: If you need to change the save format for any manager:
     * Update the corresponding saveXXX() / loadXXX() pair below
     * Keep the public API (saveAllData / loadAllData) unchanged
     */

    // Individual Save/Laod
    private static void saveAirports(AirportManager am) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(AIRPORTS_FILE))) {
            for (Airport a : am.getAirports()) {
                pw.println(a.getAirportCode() + "|" + a.getName() + "|" + a.getLocation());
            }
        } catch (IOException e) {
            System.err.println("Error saving airports: " + e.getMessage());
        }
    }

    private static void loadAirports(AirportManager am) {
        try (Scanner sc = new Scanner(new File(AIRPORTS_FILE))) {
            while (sc.hasNextLine()) {
                String[] parts = sc.nextLine().split("\\|");
                if (parts.length >= 3) {
                    Airport airport = new Airport(
                        parts[0].trim(),
                        parts[1].trim(),
                        parts[2].trim()
                    );

                    airport.addTerminal(new Terminal("T1", "T1"));
                    airport.addTerminal(new Terminal("T2", "T2"));

                    am.addAirport(airport);
                }
            }
        } catch (IOException e) {
            // First run – no file yet
        }
    }

    private static void saveFlights(FlightManager fm) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(FLIGHTS_FILE))) {
            for (Flight f : fm.getAllFlights()) {
                pw.println(
                    f.getFlightNumber() + "|" +
                    f.getOriginAirportCode() + "|" +
                    f.getDestinationAirportCode() + "|" +
                    f.getDepartureTerminal().getTerminalId() + "|" +
                    f.getArrivalTerminal().getTerminalId() + "|" +
                    f.getDepartureSchedule().getScheduleID() + "|" +
                    f.getDepartureSchedule().getDepartureTime() + "|" +
                    f.getDepartureSchedule().getArrivalTime() + "|" +
                    f.getStatus() + "|" +
                    f.getPrice()
                );
            }    
        } catch (IOException e) {
            System.err.println("Error saving flights: " + e.getMessage());
        }
    }

    private static void loadFlights(FlightManager fm, AirportManager am) {
        try (Scanner sc = new Scanner(new File(FLIGHTS_FILE))) {
            while (sc.hasNextLine()) {
                String[] parts = sc.nextLine().split("\\|");
                if (parts.length >= 10) {
                    String flightNum = parts[0].trim();
                    String originCode = parts[1].trim();
                    String destCode = parts[2].trim();
                    String depTermCode = parts[3].trim();
                    String arrTermCode = parts[4].trim();
                    String scheduleID = parts[5].trim();
                    String depTime = parts[6].trim();
                    String arrTime = parts[7].trim();
                    String status = parts[8].trim();
                    double price = Double.parseDouble(parts[9].trim());

                    Airport origin = null, dest = null;
                    for (Airport a : am.getAllAirports()) {  // uses the new getAllAirports()
                        if (a.getAirportCode().equals(originCode)){
                            origin = a;
                        }
                        if (a.getAirportCode().equals(destCode)){
                            dest = a;
                        }
                    }
                    
                    if (origin == null || dest == null) {
                        System.err.println("Skipping flight " + flightNum +
                            " because airport code was not found. Origin: " +
                            originCode + ", Destination: " + destCode);
                        continue;
                    }

                    Terminal depTerminal = new Terminal(depTermCode, depTermCode);
                    Terminal arrTerminal = new Terminal(arrTermCode, arrTermCode);

                    Schedule depSch = new Schedule(scheduleID, depTime, arrTime);
                    Schedule arrSch = new Schedule(scheduleID, depTime, arrTime);

                    Aircraft defaultAircraft = new Aircraft("AC-" + flightNum, "Boeing 737", 180);
                    defaultAircraft.generateSeats();

                    Flight f = new Flight(flightNum, origin, dest, depTerminal, arrTerminal, depSch, arrSch, status, defaultAircraft);

                    f.setPrice(price);

                    fm.addFlight(f);
                }
            }
        } catch (IOException e) {
            // First run
        } catch (Exception e) {
            System.err.println("Error loading flights: " + e.getMessage());
        }
    }

    private static void saveStaff(StaffManager sm) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(STAFF_FILE))) {
            for (Staff s : sm.getAllStaff()) {
                pw.println(
                    s.getStaffID() + "|" +
                    s.getName() + "|" +
                    s.getContactInfo() + "|" +
                    s.getRole());
            }
        } catch (IOException e) {
            System.err.println("Error saving staff: " + e.getMessage());
        }
    }

    private static void loadStaff(StaffManager sm) {
        try (Scanner sc = new Scanner(new File(STAFF_FILE))) {
            while (sc.hasNextLine()) {
                String[] parts = sc.nextLine().split("\\|");

                if (parts.length >= 4) {
                    String id = parts[0].trim();
                    String name = parts[1].trim();
                    String contact = parts[2].trim();
                    String role = parts[3].trim();

                    Staff s = new Staff(name, contact, id, role);
                    sm.addStaff(s);
                }
            }
        } catch (IOException e) {
            // First run
        }
    }

    private static void savePassengers(PassengerManager pm) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(PASSENGERS_FILE))) {
            for (Passenger p : pm.getAllPassengers()) {
                pw.println(
                        p.getPassengerID() + "|" +
                        p.getName() + "|" +
                        p.getContactInfo() + "|" +
                        p.getPassportNumber()
                );
            }
        } catch (IOException e) {
            System.err.println("Error saving passengers: " + e.getMessage());
        }
    }

    private static void loadPassengers(PassengerManager pm) {
        try (Scanner sc = new Scanner(new File(PASSENGERS_FILE))) {
            while (sc.hasNextLine()) {
                String[] parts = sc.nextLine().split("\\|");
                if (parts.length >= 4) {
                    Passenger p = new Passenger(
                            parts[1].trim(), parts[2].trim(), parts[0].trim(), parts[3]
                    );
                    pm.addPassenger(p);
                }
            }
        } catch (IOException e) {
            // First run
        }
    }

    private static void saveBookings(BookingManager bm) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(BOOKINGS_FILE))) {
            for (Booking b : bm.getAllBookings()) {
                String passengerID = (b.getPassenger() != null) ? b.getPassenger().getPassengerID() : "UNKNOWN";
                pw.println(b.getBookingID() + "|" + passengerID + "|" + b.getStatus());
            }
        } catch (IOException e) {
            System.err.println("Error saving bookings: " + e.getMessage());
        }
    }

    private static void loadBookings(BookingManager bm, PassengerManager pm, FlightManager fm) {
        try (Scanner sc = new Scanner(new File(BOOKINGS_FILE))) {
            while (sc.hasNextLine()) {
                String[] parts = sc.nextLine().split("\\|");
                if (parts.length >= 3) {
                    String bookingID = parts[0].trim();
                    String passengerID = parts[1].trim();
                    String status = parts[2].trim();

                    Passenger p = pm.findPassenger(passengerID);

                    if (p != null) {
                        Booking b = new Booking(bookingID, new Date(), p);

                        // IMPORTANT: restore saved status from bookings.txt
                        b.setStatus(status);

                        bm.addBooking(b);
                    }
//                    Booking b = new Booking(bookingID, passengerID, new Date());
//                    bm.addBooking(b);
                }
            }
        } catch (IOException e) {
            // First run
        }
    }

    private static void saveTickets(TicketManager tm) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(TICKETS_FILE))) {
            for (Ticket t : tm.getAllTickets()) {
                pw.println(t.getTicketID() + "|" +
                           t.getFlight().getFlightNumber() + "|" +
                           t.getSeat().getSeatNumber() + "|" +
                           t.getStatus() + "|" +
                           t.getPassenger().getPassengerID());
            }
        } catch (IOException e) {
            System.err.println("Error saving tickets: " + e.getMessage());
        }
    }

    private static void loadTickets(TicketManager tm, FlightManager fm,
                                    PassengerManager pm, BookingManager bm) {
        try (Scanner sc = new Scanner(new File(TICKETS_FILE))) {
            while (sc.hasNextLine()) {
                String[] parts = sc.nextLine().split("\\|");
                if (parts.length >= 5) {
                    String ticketID = parts[0].trim();
                    Flight flight = fm.findFlight(parts[1].trim());
                    Passenger passenger = pm.findPassenger(parts[4].trim());
                    String seatNum = parts[2].trim();
                    String status = parts[3].trim();

                    if (flight != null && passenger != null && flight.getAircraft() != null) {
                        Seat seat = flight.getAircraft().findSeat(seatNum);
                        Ticket t = new Ticket(ticketID, flight, seat, status, passenger);
                        tm.addTicket(t);

                        if (seat != null) {
                            seat.setAvailability(false);   // restores seat state
                        }
                    }
                }
            }
        } catch (IOException e) {
            // First run
        }
    }
}
